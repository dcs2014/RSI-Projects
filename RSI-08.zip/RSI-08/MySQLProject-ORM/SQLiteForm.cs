﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceStack.OrmLite;
using ServiceStack.OrmLite.Sqlite;
using ServiceStack.Text;
using ServiceStack.DataAnnotations;
using System.Data;
using System.Text;


namespace OrmLiteExample
{
    public class Program
    {
        // Updated using excellent feedback from Demis Bellot
        public static string SqliteMemoryDb = ":file:";
        public static string SqliteFileDb = "c:\\users\\user\\db.sqlite";

        public static void SQLiteTest(string[] args)
        {
            //Using Sqlite DB
            var dbFactory = new OrmLiteConnectionFactory(SqliteFileDb, SqliteDialect.Provider, true);

            using (var db = dbFactory.Open())
            {

                db.CreateTableIfNotExists<Note>();

                // Insert
                db.Insert(
                    new Note
                    {
                        SchemaUri = "tcm:0-0-0",
                        NoteText = "Hello world 5",
                        LastUpdated = new DateTime(2013, 1, 5),
                        UpdatedBy = "RC"
                    });

                // Read
                var notes = db.Where<Note>(new { SchemaUri = "tcm:0-0-0" });
                foreach (Note note in notes)
                {
                    Console.WriteLine("note id=" + note.Id + "noteText=" + note.NoteText);
                }

                db.Close();
            }
            Console.ReadLine();

            
        }

        public static void SQLiteTest(string[] args, object T)
        {
            //Using Sqlite DB
            var dbFactory = new OrmLiteConnectionFactory(SqliteFileDb, SqliteDialect.Provider, true);

            using (var db = dbFactory.Open())
            {

                db.CreateTableIfNotExists<Note>();

                // Insert
                db.Insert(
                    new Note
                    {
                        SchemaUri = "tcm:0-0-0",
                        NoteText = "Hello world 5",
                        LastUpdated = new DateTime(2013, 1, 5),
                        UpdatedBy = "RC"
                    });

                // Read
                var notes = db.Where<Note>(new { SchemaUri = "tcm:0-0-0" });
                foreach (Note note in notes)
                {
                    Console.WriteLine("note id=" + note.Id + "noteText=" + note.NoteText);
                }

                db.Close();
            }
            Console.ReadLine();


        }


        public class Note
        {
            [AutoIncrement] // Creates Auto primary key
            public int Id { get; set; }

            public string SchemaUri { get; set; }
            public string NoteText { get; set; }
            public DateTime? LastUpdated { get; set; }
            public string UpdatedBy { get; set; }
        }
    }
}
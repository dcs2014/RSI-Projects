﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SalarDbCodeGenerator")]
[assembly: AssemblyDescription("Database rational code generator for .NET Framework based on pattern projects.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SalarDbCodeGenerator")]
[assembly: AssemblyCopyright("Copyright © 2009-2013 All Rights Reserved")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c42fbf10-7fd7-4406-9e3f-48f0f0c3e68f")]

[assembly: AssemblyVersion("3.0.2013.0813")]
[assembly: AssemblyFileVersion("3.0.2013.0813")]
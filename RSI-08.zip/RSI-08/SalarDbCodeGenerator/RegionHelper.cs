﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// ====================================
// SalarDbCodeGenerator
// http://SalarDbCodeGenerator.codeplex.com
// Salar Khalilzadeh <salar2k@gmail.com>
// © 2012, All rights reserved
// 2009-9-30
// ====================================
namespace SalarDbCodeGenerator
{
	class RegionHelper
	{
		#region local variables
		#endregion

		#region field variables
		#endregion

		#region properties
		#endregion

		#region public methods
		#endregion

		#region protected methods
		#endregion

		#region private methods
		#endregion
	
	}
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using weka.core.converters;

using weka.core;

namespace WindowsFormsApplication1
{
    public class utils
    {


        public static string text2arff(string file, string result)
        {

            string c = "";

            return "";
        }



    }


    public class TextDirectoryToArff
    {

        public Instances createDataset(String directoryPath)
        {

            FastVector atts = new FastVector(2);
            atts.addElement(new weka.core.Attribute("filename", (FastVector)null));
            atts.addElement(new weka.core.Attribute("contents", (FastVector)null));
            Instances data = new Instances("text_files_in_" + directoryPath, atts, 0);



            DirectoryInfo dir = new DirectoryInfo(directoryPath);
            FileInfo[] files = dir.GetFiles();

            string[] exts = { ".html", ".htm", ".aspx", ".txt", ".php", ".", "" };

            for (int i = 0; i < files.Length; i++)
            {

                string ext = Path.GetExtension(files[i].FullName);

                if (exts.Contains(ext) == true)

                    try
                    {
                        double[] newInst = new double[2];
                        newInst[0] = (double)data.attribute(0).addStringValue(files[i].FullName);
                        string text = File.ReadAllText(files[i].FullName);
                        newInst[1] = (double)data.attribute(1).addStringValue(text);
                        data.add(new Instance(1.0, newInst));
                    }
                    catch (Exception e)
                    {

                    }
            }
            return data;
        }

        public static Instances text2arff(string directoryPath)
        {

            if (Directory.Exists(directoryPath) == true)
            {
                TextDirectoryToArff tdta = new TextDirectoryToArff();
                try
                {
                    Instances dataset = tdta.createDataset(directoryPath);

                    return dataset;

                    //System.out.println(dataset);
                }
                catch (Exception e)
                {
                    //System.err.println(e.getMessage());
                    //e.StackTraceprintStackTrace();
                }
            }
            else
            {
                Console.Write("Usage: java TextDirectoryToArff <directory name>");
            }


            return null;

        }


        static public void instances2disc(Instances dataSet, string filepath)
        {


            ArffSaver saver = new ArffSaver();
            saver.setInstances(dataSet);
            //saver.setFile(new java.io.File("./data/test.arff"));
            //saver.setDestination(new java.io.File("./data/test.arff"));   // **not** necessary in 3.5.4 and later


            saver.setFile(new java.io.File(filepath));
            saver.setDestination(new java.io.File(filepath));

            saver.writeBatch();




        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using ExpTree_Demo_CS;

using weka.core;
using weka.core.converters;

namespace WEKAForms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            sp = splitContainer1;

            lb = listBox1;

            tec = toolStripTextBox1;

            cont = new Controller();

            mc = new mvc();
            
            loadExpForm();

            mc.register(sp);

            mc.master = sp;

            exts = new extender();

            exts.register_src(frm.teb);

            exts.register_dst(tec);


        }

        public ListBox lb { get; set;}

        public ToolStripTextBox tec { get; set; }

        public SplitContainer sp { get; set; }

            public ExpTree_Demo_CS.frmThreadCS frm {get; set;}

            public Controller cont { get; set; }

            public mvc mc { get; set; }

            public extender exts { get; set; }

            public void loadExpForm()
            {

                frm = new frmThreadCS();
                frm.Dock = DockStyle.Fill;
                frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                frm.TopLevel = false;

                frm.sp.Panel2Collapsed = true;


                string s = AppDomain.CurrentDomain.BaseDirectory;

                frm.loadfilepath(s);

                //this.Controls.Add(frm);

                //frm.Show(this);

                //cont.addview(frm);

                mc.register(frm);

            }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            //DialogResult r = folderBrowserDialog1.ShowDialog();

            //if (r != System.Windows.Forms.DialogResult.OK)
            //    return;

            //string directoryPath = folderBrowserDialog1.SelectedPath;

            string directoryPath = tec.Text;


          


            if (Directory.Exists(directoryPath) == false)
            {

                if (File.Exists(directoryPath) == true)
                {

                    directoryPath = directoryPath.Replace(Path.GetFileName(directoryPath), "");

                }

                if (Directory.Exists(directoryPath) == false) { 

                MessageBox.Show("Directory does not exists");
                return;
            }
            }

            Instances dataSet = TextDirectoryToArff.text2arff(directoryPath);

            loadInstances(dataSet);

            ds = dataSet;

            TextDirectoryToArff.instances2disc(dataSet, "testdata.arff");

        }

        public Instances ds { get; set; }

        public void loadInstances(Instances b)
        {

            lb.Items.Clear();

            int N = b.numInstances();
            for (int i = 0; i < N; i++ )

              
                {

                    Instance c = b.instance(i);
                
                    string s = c.toString();
                                                     
                    //lb.Items.Add(c.stringValue(0));

                    lb.Items.Add(s);

                }

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            //cont.next(this);

            mc.toggle(frm, this);
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int i = lb.SelectedIndex;
            if (i < 0)
                return;
            string s = lb.Items[i].ToString();

            richTextBox1.Text = s;

        }

    }
}

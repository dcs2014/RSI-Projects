﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


using System.Collections;

using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using System.Windows.Forms;


namespace WEKAForms
{
    public class Controller
    {

        public ArrayList W = new ArrayList();


        public int act = 0;

        public void addview(Control _c)
        {
            W.Add(_c);

        }

        public void removeview(Control _c)
        {

            int index = W.IndexOf(_c);

            if (index >= 0)
                W.RemoveAt(index);

        }

        public ArrayList getviews()
        {
            return W;
        }

        public Control getact()
        {

            if (W.Count <= act)
                return new Control();

            return (Control)W[act];


        }

        public string nextview()
        {

            act++;
            if (act == W.Count)
                act = 0;

            Control c = (Control)W[act];

            return c.Name;
        }

        public Control nextviewcontrol()
        {

            act++;
            if (act == W.Count)
                act = 0;

            Control c = (Control)W[act];

            return c;
        }

        public string getactview()
        {

            if (act > W.Count - 1)
                return "e";

            Control c = (Control)W[act];

            return c.Name;

        }

        public void registerlogger(Control c)
        {

            logger = c;

        }

        public Control logger { get; set; }

        public Control getlogger()
        {

            return logger;

        }

        public Control Parent { get; set; }

        public void update_z_order(Control p)
        {

            p.SuspendLayout();

            ArrayList L = new ArrayList();

            //foreach (Control c in Controls)
            //{

            //    L.Add(c);
            //}
            foreach (Control c in p.Controls)
            {
                L.Add(c);
            }

            foreach (Control c in L)
            {

                if (c.GetType() == typeof(ToolStripPanel) || c.GetType() == typeof(ToolStrip))
                    p.Controls.Remove(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true || c.GetType() == typeof(MenuStrip))
                    p.Controls.Remove(c);

            }
            foreach (Control c in L)
            {
                if (c.GetType() == typeof(ToolStrip))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(ToolStripPanel))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(MenuStrip))
                    p.Controls.Add(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true)
                    p.Controls.Add(c);

            }



            p.ResumeLayout();
        }


        public void control(Control cc)
        {

            ArrayList L = getviews();

            //Control act = getact();


            act = L.IndexOf(cc);

            //Control next = nextviewcontrol();



            foreach (Control c in L)
            {

                if (cc == c)
                {
                    c.Visible = true;

                }
                else
                    c.Visible = false;


            }

            ArrayList W = new ArrayList();

            W.AddRange(L);

            //W.Add(toolStrip1);

            update_z_order(Parent);
        }


        public void next(Control p)
        {

            ArrayList L = getviews();

            Control act = getact();

            Control next = nextviewcontrol();

            foreach (Control c in L)
            {

                if (c == next)
                {
                    c.Visible = true;

                }
                else
                    c.Visible = false;


            }

            ArrayList W = new ArrayList();

            W.AddRange(L);

            //W.Add(toolStrip1);

            update_z_order(p);
        }

        public void next()
        {

            ArrayList L = getviews();

            Control act = getact();

            Control next = nextviewcontrol();

            foreach (Control c in L)
            {

                if (c == next)
                {
                    c.Visible = true;

                }
                else
                    c.Visible = false;


            }

            ArrayList W = new ArrayList();

            W.AddRange(L);

            //W.Add(toolStrip1);
            if (mc == null)
                return;
            update_z_order(Parent);
        }


        public Control mc { get; set; }

      
    }


    public class mvc
    {


        public ArrayList regs { get; set; }

        public void register(Control c)
        {

            if (regs == null)
                regs = new ArrayList();

            int index = regs.IndexOf(c);

            if (index >= 0)
                return;

            regs.Add(c);



        }

        public Control master { get; set; }

        public void toggle(Control s, Control c)
        {

            if (regs == null)
                regs = new ArrayList();

            if (s.Visible == false)
            {

                c.Controls.Add(s);
                s.Visible = true;


                //c.Controls.Remove(panel);
                //panel.Visible = false;

                foreach (Control cc in regs)
                {

                    if (cc == s) continue;

                    cc.Visible = false;

                }

                update_z_order(c);

                //fader();
            }
            else
            {

                //c.Controls.Add(panel);
                //panel.Visible = true;

                c.Controls.Remove(s);

                s.Visible = false;

                if (master == null)
                    return;

                master.Visible = true;


                update_z_order(c);


            }



        }

        public void update_z_order(Control p)
        {

            p.SuspendLayout();

            ArrayList L = new ArrayList();

            //foreach (Control c in Controls)
            //{

            //    L.Add(c);
            //}
            foreach (Control c in p.Controls)
            {
                L.Add(c);
            }

            foreach (Control c in L)
            {

                if (c.GetType() == typeof(ToolStripPanel) || c.GetType() == typeof(ToolStrip))
                    p.Controls.Remove(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true || c.GetType() == typeof(MenuStrip))
                    p.Controls.Remove(c);

            }
            foreach (Control c in L)
            {
                if (c.GetType() == typeof(ToolStrip))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(ToolStripPanel))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(MenuStrip))
                    p.Controls.Add(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true)
                    p.Controls.Add(c);

            }



            p.ResumeLayout();
        }

    }

    public class extender
    {


        public void doinit()
        {
            //register_dst(dst);


        }


        public TextBox src { get; set; }

        public ToolStripTextBox dst { get; set; }


        public void register_dst(ToolStripTextBox _tb)
        {

            dst = _tb;




        }

        public void register_src(TextBox _tb)
        {

            src = _tb;

            src.TextChanged += new EventHandler(changefilepath);

        }


        public void changefilepath(object sender, EventArgs e)
        {

            if (sender == null)
                return;

            TextBox tb = (TextBox)sender as TextBox;

            dst.Text = tb.Text;

        }




    }


}

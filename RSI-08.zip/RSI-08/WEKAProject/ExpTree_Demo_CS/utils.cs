﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Windows.Forms;
using System.Text;
using System.Threading.Tasks;


namespace ExpTree_Demo_CS
{
    public class utils
    {

        static public void serialize(string file, Dictionary<string, string> dict)
        {
                     
           

            IFormatter formatter = new BinaryFormatter();

            // serialize to disk
            using (FileStream s = File.Create(file))
            {
                formatter.Serialize(s, dict);
            }

            // deserialize to a new dictionary

            //Dictionary<string, string> dict2;
            //using (FileStream s = File.OpenRead("dictionary.bin"))
            //{
            //    dict2 = (Dictionary<string, string>)formatter.Deserialize(s);
            //}

        
        }

        public static Dictionary<string, string> deserialize(string file)
        {
            // Declare the hashtable reference.
            Dictionary<string, string> dict = null;

            // Open the file containing the data that you want to deserialize.
            FileStream fs = new FileStream(file, FileMode.Open);
            try
            {
                BinaryFormatter formatter = new BinaryFormatter();

                // Deserialize the hashtable from the file and 
                // assign the reference to the local variable.
                dict = (Dictionary<string,string>)formatter.Deserialize(fs);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Failed to deserialize. Reason: " + e.Message);
                throw;
            }
            finally
            {
                fs.Close();
            }

            return dict;
        }

        static public void get_dir_content(ListBox lb, string p)
        {

            if (Directory.Exists(p) == false)
                Directory.CreateDirectory(p);

            lb.Items.Clear();
            string[] filePaths = Directory.GetFiles(@p, "*.*",
                                         SearchOption.AllDirectories);
            foreach (string s in filePaths)
            {
                if (Directory.Exists(s))
                {
                    get_dir_content(lb, s);
                    return;
                }
                lb.Items.Add(s);
            }
        }

    }

    public class Controller
    {

        public ArrayList W = new ArrayList();


        public int act = 0;

        public void addview(Control _c)
        {
            W.Add(_c);

        }

        public void removeview(Control _c)
        {

            int index = W.IndexOf(_c);

            if (index >= 0)
                W.RemoveAt(index);

        }

        public ArrayList getviews()
        {
            return W;
        }

        public Control getact()
        {

            if (W.Count <= act)
                return new Control();

            return (Control)W[act];


        }

        public string nextview()
        {

            act++;
            if (act == W.Count)
                act = 0;

            Control c = (Control)W[act];

            return c.Name;
        }

        public Control nextviewcontrol()
        {

            act++;
            if (act == W.Count)
                act = 0;

            Control c = (Control)W[act];

            return c;
        }

        public string getactview()
        {

            if (act > W.Count - 1)
                return "e";

            Control c = (Control)W[act];

            return c.Name;

        }

        public void registerlogger(Control c)
        {

            logger = c;

        }

        public Control logger { get; set; }

        public Control getlogger()
        {

            return logger;

        }


        public void update_z_order(Control p)
        {

            p.SuspendLayout();

            ArrayList L = new ArrayList();

            //foreach (Control c in Controls)
            //{

            //    L.Add(c);
            //}
            foreach (Control c in p.Controls)
            {
                L.Add(c);
            }

            foreach (Control c in L)
            {

                if (c.GetType() == typeof(ToolStripPanel) || c.GetType() == typeof(ToolStrip))
                    p.Controls.Remove(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true || c.GetType() == typeof(MenuStrip))
                    p.Controls.Remove(c);

            }
            foreach (Control c in L)
            {
                if (c.GetType() == typeof(ToolStrip))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(ToolStripPanel))
                    p.Controls.Add(c);
                if (c.GetType() == typeof(MenuStrip))
                    p.Controls.Add(c);
                if (c.GetType().IsSubclassOf(typeof(MenuStrip)) == true)
                    p.Controls.Add(c);

            }



            p.ResumeLayout();
        }

        public void next(Control p)
        {

            ArrayList L = getviews();

            Control act = getact();

            Control next = nextviewcontrol();

            foreach (Control c in L)
            {

                if (c == next)
                {
                    c.Visible = true;

                }
                else
                    c.Visible = false;


            }

            ArrayList W = new ArrayList();

            W.AddRange(L);

            //W.Add(toolStrip1);

            update_z_order(p);
        }


    }

    public class Explorer
    {

        public Controller cont { get; set; }


        public void doinit()
        {

            cont = new Controller();

        }

        public void register(Control _c)
        {

            if (cont == null)
                cont = new Controller();


            cont.addview(_c);
        }


        public Control parent { get; set; }


        public ExpTree_Demo_CS.frmThreadCS frm { get; set; }

        public void create_dirs_form(Control p)
        {



            // //Form1 form = new Form1("key");
            // //form.update_z_order();
            frm = new frmThreadCS();
            frm.Dock = DockStyle.Fill;
            frm.TopLevel = false;

            frm.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

            //frm.Show();
            //this.update_z_order(); 

           
            frm.Show();


            p.Controls.Add(frm);



            register(frm);

            cont.next(p);

           // frm.lv1.SelectedIndexChanged += new EventHandler(afterselect);
        }

        public TextBox tb { get; set; }

        //public void afterselect(object sender, EventArgs args)
        //{
        //    if (frm == null)
        //        return;

        //    if (frm.lv1.SelectedIndices == null)
        //        return;
        //    if (frm.lv1.SelectedIndices.Count <= 0)
        //        return;

        //    int index = frm.lv1.SelectedIndices[0];

        //    ListViewItem vv = frm.lv1.Items[index];

        //    string frm.sel

        //    if(vv.Tag == null)
        //        return;

        //    //string s = vv.Tag as string;

        //    if (tb == null)
        //        return;

            

        //    tb.Text = vv.Tag.ToString();
        //}

        public void folder_change(string s)
        {

            if (frm == null)
                return;
            frm.loadfilepath(s);

        }

        public linker lnk { get; set; }

        public void create_links_form(Control p, TreeView tv)
        {

            lnk = new linker();

            lnk.load_control(tv);

            lnk.Dock = DockStyle.Fill;
            //lnk.TopLevel = false;

            //lnk.BorderStyle = System.Windows.Forms.BorderStyle.None;

            //frm.Show();
            //this.update_z_order(); 

            lnk.Show();

            p.Controls.Add(lnk);

            register(lnk);

            cont.next(p);


        }

        public void create_links_form(Control p)
        {

            lnk = new linker();

            lnk.load_control();

            lnk.Dock = DockStyle.Fill;
            //lnk.TopLevel = false;

            //lnk.Border = BorderStyle.None;

            //frm.Show();
            //this.update_z_order(); 

            lnk.Show();

            p.Controls.Add(lnk);

            register(lnk);

            cont.next(p);


        }

    }


    public class linker : Control
    {

        public void load_control(TreeView _tv)
        {



        }

        public void load_control(){

            tv = new TreeView();
            tv.Dock = DockStyle.Fill;
            tv.BorderStyle = BorderStyle.None;

            this.Controls.Add(tv);

        }

        public TreeView tv { get; set; }

        public void load_links(string file, TreeView tv)
        {


            string[] s = File.ReadLines(file).ToArray();

            load_fromarray(s, tv);

        }

        public bool linkeditmode = false;

         public void load_links(string file)
        {

            if(linkeditmode == true)
                return;

            try
            {
                string[] s = File.ReadLines(file).ToArray();

                load_fromarray(s, tv);
            }
            catch (Exception ex) { };
        }


         public string linkedfilepath { get; set; }

         public void load_links_editor(string file)
         {

             if (linkeditmode == true)
             {

                 linkeditmode = false;
                 linkedfilepath = "";
                 return;

             }
             else
             {

                 linkeditmode = true;
                 linkedfilepath = file;
                 return;

             }

             //try
             //{
             //    string[] s = File.ReadLines(file).ToArray();

             //    load_fromarray(s, tv);
             //}
             //catch (Exception ex) { };

         }

        public void load_fromarray(string []s){

            load_fromarray(s, tv);

        }

        public void load_fromarray(string[] s, TreeView tv)
        {

            tv.Nodes.Clear();

            foreach (string p in s)
            {

                TreeNode node = new TreeNode();
                node.Text = p;
                node.Tag = p;

                tv.Nodes.Add(node);
            }

        }

        public void add_file_path(string s)
        {

            if (tv == null)
                return;
            TreeNode node = new TreeNode();
            node.Text = s;
            node.Tag = s;

            tv.Nodes.Add(node);

        }

        public void create_fromControl(string file, TreeView tv)
        {

            StringBuilder sb = new StringBuilder();

            ArrayList buffer = new ArrayList();

            //file = textBox1.Text;

            //string dir = textBox2.Text;

            foreach (TreeNode node in tv.Nodes)
            {

                buffer.Add(node.Text);

                sb.AppendLine(node.Text);



            }

            string s = sb.ToString();

            //file = dir + "\\" + file;

            File.WriteAllText(file, s);

        }

        public void create_fromControl(string file)
        {
            string files = linkedfilepath;

            if (files == "")
                return;

            StringBuilder sb = new StringBuilder();

            ArrayList buffer = new ArrayList();

            //file = textBox1.Text;

            //string dir = textBox2.Text;

            foreach (TreeNode node in tv.Nodes)
            {

                buffer.Add(node.Text);

                sb.AppendLine(node.Text);



            }

            string s = sb.ToString();

            //file = dir + "\\" + file;

            File.WriteAllText(files, s);

        }

        public string afterselect(object sender, TreeViewEventArgs e)
        {

            if (tv.SelectedNode == null)
                return "";

            TreeNode node = tv.SelectedNode;

            string file = node.Text;

            return file;

        }

        public string getselected()
        {

            if (tv.SelectedNode == null)
                return "";

            TreeNode node = tv.SelectedNode;

            string file = node.Text;

            return file;

        }

        public void savelnks(string s)
        {

            string c = "";

            foreach (TreeNode node in tv.Nodes)
            {

                c += node.Text + "\n";
                
            }

            File.WriteAllText(s, c);

        }

    }


}

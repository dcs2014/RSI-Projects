using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using SalarDb.CodeGen.Model;
using SalarDb.CodeGen.Common;

namespace SalarDb.CodeGen.DAL
{
	/// <summary>
	/// User custom methods for mp3
	/// </summary>
	partial class mp3DAL
	{

	}
}

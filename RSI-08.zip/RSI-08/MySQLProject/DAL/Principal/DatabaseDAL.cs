using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using SalarDb.CodeGen.Base;
using SalarDb.CodeGen.Model;
using SalarDb.CodeGen.Common;

namespace SalarDb.CodeGen.DAL
{

	/// <summary>
	/// Data access layer for author
	/// </summary>
	public partial class authorDAL : Ows_indexDALBase
	{
		internal authorDAL()
		{

		}
		internal authorDAL(Ows_indexDbTransaction transaction, IDbConnection connection)
		{
			Connection = connection;
			Transaction = transaction;
		}

		public List<authorModel> GetAll()
		{
			List<authorModel> result = new List<authorModel>();

			using (MySqlCommand cmd = GetNewCommand())
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "author_GetAll";

				IDataReader reader = null;
				try
				{
					reader = Ows_indexDbProvider.ExecuteReader(cmd);
					authorModel.FieldsOrdinal fields = new authorModel.FieldsOrdinal(reader);
					while (reader.Read())
					{
						authorModel model = new authorModel();
						model.ReadData(reader, fields);
						result.Add(model);
					}
				}
				catch (Exception)
				{
					throw;
				}
				finally
				{
					if (reader != null)
						reader.Close();
				}
			}
			return result;
		}

		public authorModel GetByAuthorID(Int32 AuthorID)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "author_GetByAuthorID";
	
					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@AuthorID", AuthorID);
	
						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							authorModel result = new authorModel();
							result.ReadData(reader);
							return result;
						}
						else
							return null;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public bool GetByAuthorID(Int32 AuthorID, authorModel result)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "author_GetByAuthorID";

					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@AuthorID", AuthorID);

						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							result.ReadData(reader);
							return true;
						}
						else
							return false;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Update(authorModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "author_Update";
	
					
					cmd.Parameters.AddWithValue("@AuthorID", model.AuthorID);
					if(model.Name!=null)
						cmd.Parameters.AddWithValue("@Name", model.Name);

					cmd.Parameters.AddWithValue("@Birthday", model.Birthday);
					if(model.LastActivity.HasValue)
						cmd.Parameters.AddWithValue("@LastActivity", model.LastActivity.Value);

					if(model.Earnings.HasValue)
						cmd.Parameters.AddWithValue("@Earnings", model.Earnings.Value);

					cmd.Parameters.AddWithValue("@Active", model.Active);
					if(model.JobCity!=null)
						cmd.Parameters.AddWithValue("@JobCity", model.JobCity);

					if(model.Comment!=null)
						cmd.Parameters.AddWithValue("@Comment", model.Comment);

					cmd.Parameters.AddWithValue("@Rate", model.Rate);
					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public Int32 Insert(authorModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "author_Insert";
	
					
					if(model.Name!=null)
						cmd.Parameters.AddWithValue("@Name", model.Name);

					cmd.Parameters.AddWithValue("@Birthday", model.Birthday);
					if(model.LastActivity.HasValue)
						cmd.Parameters.AddWithValue("@LastActivity", model.LastActivity.Value);

					if(model.Earnings.HasValue)
						cmd.Parameters.AddWithValue("@Earnings", model.Earnings.Value);

					cmd.Parameters.AddWithValue("@Active", model.Active);
					if(model.JobCity!=null)
						cmd.Parameters.AddWithValue("@JobCity", model.JobCity);

					if(model.Comment!=null)
						cmd.Parameters.AddWithValue("@Comment", model.Comment);

					cmd.Parameters.AddWithValue("@Rate", model.Rate);

					
					Object result = null;
					result = Ows_indexDbProvider.ExecuteScalar(cmd);
					if (result == null || Convert.IsDBNull(result))
						throw new Exception("Can not get inserted auto number from db.");
					else
						return Convert.ToInt32(result);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Delete(Int32 AuthorID)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "author_DeleteByAuthorID";
	
					cmd.Parameters.AddWithValue("@AuthorID", AuthorID);
	
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}




		public authorModel GetByName(String Name)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "author_GetByName";
	
					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@Name", Name);
	
						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							authorModel result = new authorModel();
							result.ReadData(reader);
							return result;
						}
						else
							return null;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void DeleteByName(String Name)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "author_DeleteByName";
	
					cmd.Parameters.AddWithValue("@Name", Name);
	
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}
	}

	/// <summary>
	/// Data access layer for images
	/// </summary>
	public partial class imagesDAL : Ows_indexDALBase
	{
		internal imagesDAL()
		{

		}
		internal imagesDAL(Ows_indexDbTransaction transaction, IDbConnection connection)
		{
			Connection = connection;
			Transaction = transaction;
		}

		public List<imagesModel> GetAll()
		{
			List<imagesModel> result = new List<imagesModel>();

			using (MySqlCommand cmd = GetNewCommand())
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "images_GetAll";

				IDataReader reader = null;
				try
				{
					reader = Ows_indexDbProvider.ExecuteReader(cmd);
					imagesModel.FieldsOrdinal fields = new imagesModel.FieldsOrdinal(reader);
					while (reader.Read())
					{
						imagesModel model = new imagesModel();
						model.ReadData(reader, fields);
						result.Add(model);
					}
				}
				catch (Exception)
				{
					throw;
				}
				finally
				{
					if (reader != null)
						reader.Close();
				}
			}
			return result;
		}

		public imagesModel GetByid(UInt32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "images_GetByid";
	
					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);
	
						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							imagesModel result = new imagesModel();
							result.ReadData(reader);
							return result;
						}
						else
							return null;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public bool GetByid(UInt32 id, imagesModel result)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "images_GetByid";

					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);

						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							result.ReadData(reader);
							return true;
						}
						else
							return false;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Update(imagesModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "images_Update";
	
					
					cmd.Parameters.AddWithValue("@id", model.id);
					cmd.Parameters.AddWithValue("@src_host_id", model.src_host_id);
					cmd.Parameters.AddWithValue("@src_page", model.src_page);
					cmd.Parameters.AddWithValue("@image_host_id", model.image_host_id);
					cmd.Parameters.AddWithValue("@image", model.image);
					if(model.alt_text!=null)
						cmd.Parameters.AddWithValue("@alt_text", model.alt_text);

					if(model.title_text!=null)
						cmd.Parameters.AddWithValue("@title_text", model.title_text);

					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Insert(imagesModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "images_Insert";
	
					
					cmd.Parameters.AddWithValue("@id", model.id);
					cmd.Parameters.AddWithValue("@src_host_id", model.src_host_id);
					cmd.Parameters.AddWithValue("@src_page", model.src_page);
					cmd.Parameters.AddWithValue("@image_host_id", model.image_host_id);
					cmd.Parameters.AddWithValue("@image", model.image);
					if(model.alt_text!=null)
						cmd.Parameters.AddWithValue("@alt_text", model.alt_text);

					if(model.title_text!=null)
						cmd.Parameters.AddWithValue("@title_text", model.title_text);


					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Delete(UInt32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "images_DeleteByid";
	
					cmd.Parameters.AddWithValue("@id", id);
	
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}



	}

	/// <summary>
	/// Data access layer for mp3
	/// </summary>
	public partial class mp3DAL : Ows_indexDALBase
	{
		internal mp3DAL()
		{

		}
		internal mp3DAL(Ows_indexDbTransaction transaction, IDbConnection connection)
		{
			Connection = connection;
			Transaction = transaction;
		}

		public List<mp3Model> GetAll()
		{
			List<mp3Model> result = new List<mp3Model>();

			using (MySqlCommand cmd = GetNewCommand())
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "mp3_GetAll";

				IDataReader reader = null;
				try
				{
					reader = Ows_indexDbProvider.ExecuteReader(cmd);
					mp3Model.FieldsOrdinal fields = new mp3Model.FieldsOrdinal(reader);
					while (reader.Read())
					{
						mp3Model model = new mp3Model();
						model.ReadData(reader, fields);
						result.Add(model);
					}
				}
				catch (Exception)
				{
					throw;
				}
				finally
				{
					if (reader != null)
						reader.Close();
				}
			}
			return result;
		}

		public mp3Model GetByid(UInt32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "mp3_GetByid";
	
					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);
	
						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							mp3Model result = new mp3Model();
							result.ReadData(reader);
							return result;
						}
						else
							return null;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public bool GetByid(UInt32 id, mp3Model result)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "mp3_GetByid";

					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);

						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							result.ReadData(reader);
							return true;
						}
						else
							return false;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Update(mp3Model model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "mp3_Update";
	
					
					cmd.Parameters.AddWithValue("@id", model.id);
					cmd.Parameters.AddWithValue("@host_id", model.host_id);
					cmd.Parameters.AddWithValue("@filename", model.filename);
					cmd.Parameters.AddWithValue("@mp3_size", model.mp3_size);
					cmd.Parameters.AddWithValue("@mp3_artist", model.mp3_artist);
					cmd.Parameters.AddWithValue("@mp3_title", model.mp3_title);
					cmd.Parameters.AddWithValue("@mp3_album", model.mp3_album);
					cmd.Parameters.AddWithValue("@mp3_genre", model.mp3_genre);
					cmd.Parameters.AddWithValue("@mp3_duration", model.mp3_duration);
					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Insert(mp3Model model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "mp3_Insert";
	
					
					cmd.Parameters.AddWithValue("@id", model.id);
					cmd.Parameters.AddWithValue("@host_id", model.host_id);
					cmd.Parameters.AddWithValue("@filename", model.filename);
					cmd.Parameters.AddWithValue("@mp3_size", model.mp3_size);
					cmd.Parameters.AddWithValue("@mp3_artist", model.mp3_artist);
					cmd.Parameters.AddWithValue("@mp3_title", model.mp3_title);
					cmd.Parameters.AddWithValue("@mp3_album", model.mp3_album);
					cmd.Parameters.AddWithValue("@mp3_genre", model.mp3_genre);
					cmd.Parameters.AddWithValue("@mp3_duration", model.mp3_duration);

					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Delete(UInt32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "mp3_DeleteByid";
	
					cmd.Parameters.AddWithValue("@id", id);
	
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}



	}

	/// <summary>
	/// Data access layer for pages
	/// </summary>
	public partial class pagesDAL : Ows_indexDALBase
	{
		internal pagesDAL()
		{

		}
		internal pagesDAL(Ows_indexDbTransaction transaction, IDbConnection connection)
		{
			Connection = connection;
			Transaction = transaction;
		}

		public List<pagesModel> GetAll()
		{
			List<pagesModel> result = new List<pagesModel>();

			using (MySqlCommand cmd = GetNewCommand())
			{
                cmd.CommandType = CommandType.Text;// StoredProcedure;
				cmd.CommandText = "SELECT * FROM pages";//pages_GetAll";

				IDataReader reader = null;
				try
				{
					reader = Ows_indexDbProvider.ExecuteReader(cmd);
					pagesModel.FieldsOrdinal fields = new pagesModel.FieldsOrdinal(reader);
					while (reader.Read())
					{
						pagesModel model = new pagesModel();
						model.ReadData(reader, fields);
						result.Add(model);
					}
				}
				catch (Exception)
				{
					throw;
				}
				finally
				{
					if (reader != null)
						reader.Close();
				}
			}
			return result;
		}

		public pagesModel GetByid(Int32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pages_GetByid";
	
					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);
	
						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							pagesModel result = new pagesModel();
							result.ReadData(reader);
							return result;
						}
						else
							return null;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public bool GetByid(Int32 id, pagesModel result)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pages_GetByid";

					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);

						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							result.ReadData(reader);
							return true;
						}
						else
							return false;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Update(pagesModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pages_Update";
	
					
					cmd.Parameters.AddWithValue("@id", model.id);
					cmd.Parameters.AddWithValue("@host_id", model.host_id);
					cmd.Parameters.AddWithValue("@hostname", model.hostname);
					cmd.Parameters.AddWithValue("@page", model.page);
					cmd.Parameters.AddWithValue("@title", model.title);
					cmd.Parameters.AddWithValue("@anchor_text", model.anchor_text);
					cmd.Parameters.AddWithValue("@text", model.text);
					if(model.cache!=null)
						cmd.Parameters.AddWithValue("@cache", model.cache);

					cmd.Parameters.AddWithValue("@html_md5", model.html_md5);
					cmd.Parameters.AddWithValue("@level", model.level);
					cmd.Parameters.AddWithValue("@rank", model.rank);
					cmd.Parameters.AddWithValue("@date", model.date);
					cmd.Parameters.AddWithValue("@time", model.time);
					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public Int32 Insert(pagesModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pages_Insert";
	
					
					cmd.Parameters.AddWithValue("@host_id", model.host_id);
					cmd.Parameters.AddWithValue("@hostname", model.hostname);
					cmd.Parameters.AddWithValue("@page", model.page);
					cmd.Parameters.AddWithValue("@title", model.title);
					cmd.Parameters.AddWithValue("@anchor_text", model.anchor_text);
					cmd.Parameters.AddWithValue("@text", model.text);
					if(model.cache!=null)
						cmd.Parameters.AddWithValue("@cache", model.cache);

					cmd.Parameters.AddWithValue("@html_md5", model.html_md5);
					cmd.Parameters.AddWithValue("@level", model.level);
					cmd.Parameters.AddWithValue("@rank", model.rank);
					cmd.Parameters.AddWithValue("@date", model.date);
					cmd.Parameters.AddWithValue("@time", model.time);

					
					Object result = null;
					result = Ows_indexDbProvider.ExecuteScalar(cmd);
					if (result == null || Convert.IsDBNull(result))
						throw new Exception("Can not get inserted auto number from db.");
					else
						return Convert.ToInt32(result);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Delete(Int32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pages_DeleteByid";
	
					cmd.Parameters.AddWithValue("@id", id);
	
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}



	}

	/// <summary>
	/// Data access layer for pdf
	/// </summary>
	public partial class pdfDAL : Ows_indexDALBase
	{
		internal pdfDAL()
		{

		}
		internal pdfDAL(Ows_indexDbTransaction transaction, IDbConnection connection)
		{
			Connection = connection;
			Transaction = transaction;
		}

		public List<pdfModel> GetAll()
		{
			List<pdfModel> result = new List<pdfModel>();

			using (MySqlCommand cmd = GetNewCommand())
			{
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.CommandText = "pdf_GetAll";

				IDataReader reader = null;
				try
				{
					reader = Ows_indexDbProvider.ExecuteReader(cmd);
					pdfModel.FieldsOrdinal fields = new pdfModel.FieldsOrdinal(reader);
					while (reader.Read())
					{
						pdfModel model = new pdfModel();
						model.ReadData(reader, fields);
						result.Add(model);
					}
				}
				catch (Exception)
				{
					throw;
				}
				finally
				{
					if (reader != null)
						reader.Close();
				}
			}
			return result;
		}

		public pdfModel GetByid(UInt32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pdf_GetByid";
	
					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);
	
						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							pdfModel result = new pdfModel();
							result.ReadData(reader);
							return result;
						}
						else
							return null;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public bool GetByid(UInt32 id, pdfModel result)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pdf_GetByid";

					IDataReader reader = null;
					try
					{
						cmd.Parameters.AddWithValue("@id", id);

						reader = Ows_indexDbProvider.ExecuteReader(cmd);
						if (reader.Read())
						{
							result.ReadData(reader);
							return true;
						}
						else
							return false;
					}
					finally
					{
						if (reader != null)
							reader.Close();
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Update(pdfModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pdf_Update";
	
					
					cmd.Parameters.AddWithValue("@id", model.id);
					cmd.Parameters.AddWithValue("@host_id", model.host_id);
					cmd.Parameters.AddWithValue("@filename", model.filename);
					cmd.Parameters.AddWithValue("@pdf_size", model.pdf_size);
					cmd.Parameters.AddWithValue("@pdf_text", model.pdf_text);
					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Insert(pdfModel model)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pdf_Insert";
	
					
					cmd.Parameters.AddWithValue("@id", model.id);
					cmd.Parameters.AddWithValue("@host_id", model.host_id);
					cmd.Parameters.AddWithValue("@filename", model.filename);
					cmd.Parameters.AddWithValue("@pdf_size", model.pdf_size);
					cmd.Parameters.AddWithValue("@pdf_text", model.pdf_text);

					
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		public void Delete(UInt32 id)
		{
			try
			{
				using (MySqlCommand cmd = GetNewCommand())
				{
					cmd.CommandType = CommandType.StoredProcedure;
					cmd.CommandText = "pdf_DeleteByid";
	
					cmd.Parameters.AddWithValue("@id", id);
	
					Ows_indexDbProvider.ExecuteNonQuery(cmd);
				}
			}
			catch (Exception)
			{
				throw;
			}
		}



	}

}

using System;
using System.Collections.Generic;
using System.Text;
using MySql.Data.MySqlClient;
using System.Data;

namespace SalarDb.CodeGen.Common
{
	public partial class DbTransaction
	{
		public static Ows_indexDbTransaction BeginTransactionOws_index()
		{
			return Ows_indexDbTransaction.BeginTransaction();
		}
	}

	public class Ows_indexDbTransaction : IDisposable
	{
		#region variables
		private IDbTransaction _SqlTransaction;
		private IDbConnection _Connection;
		#endregion

		#region properties
		internal IDbConnection Connection
		{
			get { return _Connection; }
			set { _Connection = value; }
		}
		#endregion

		#region static methods
		public static Ows_indexDbTransaction BeginTransaction()
		{
			Ows_indexDbTransaction result = new Ows_indexDbTransaction();
			result._Connection = Ows_indexDbProvider.GetNewConnection();

			// Openning transaction connection
			result._Connection.Open();

			// Begin the trasnaction
			result._SqlTransaction = result._Connection.BeginTransaction();

			return result;
		}
		#endregion

		#region public methods
		private Ows_indexDbTransaction()
		{
			// User shouldn't create
		}

		public void Dispose()
		{
			if (_SqlTransaction != null)
				_SqlTransaction.Dispose();
			if (_Connection != null)
				_Connection.Dispose();
		}

		public void Commit()
		{
			_SqlTransaction.Commit();
		}

		public void Rollback()
		{
			_SqlTransaction.Rollback();
		}
		#endregion

		#region protected methods
		internal MySqlCommand GetNewCommand()
		{
			IDbCommand cmd = _SqlTransaction.Connection.CreateCommand();
			cmd.Transaction = _SqlTransaction;
			return (MySqlCommand)cmd;
		}
		#endregion
	}
}

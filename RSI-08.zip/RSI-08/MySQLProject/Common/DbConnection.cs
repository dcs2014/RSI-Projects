using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace SalarDb.CodeGen.Common
{
	static class Ows_indexDbConnection
	{
		internal static IDbConnection GetNewConnection()
		{
			return new MySqlConnection(GetConnectionString());
		}

		internal static String GetConnectionString()
		{
			//return ConfigurationManager.ConnectionStrings["Ows_indexConnectionString"].ConnectionString;

            return "Server = 127.0.0.1; Database = ows_index; Uid = root; Pwd =";
		}
	}
}

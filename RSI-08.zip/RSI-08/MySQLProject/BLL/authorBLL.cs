using System;
using System.Collections.Generic;
using System.Text;
using SalarDb.CodeGen.Base;
using SalarDb.CodeGen.Model;
using SalarDb.CodeGen.DAL;

namespace SalarDb.CodeGen.BLL
{
	/// <summary>
	/// User custom methods for author
	/// </summary>
	partial class authorBLL
	{

	}
}

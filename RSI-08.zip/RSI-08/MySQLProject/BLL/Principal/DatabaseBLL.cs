using System;
using System.Collections.Generic;
using System.Text;
using SalarDb.CodeGen.Base;
using SalarDb.CodeGen.Model;
using SalarDb.CodeGen.DAL;

namespace SalarDb.CodeGen.BLL
{

	/// <summary>
	/// Business logic for author
	/// </summary>
	public partial class authorBLL : Ows_indexBLLBase
	{
		public List<authorModel> GetAll()
		{
			using (authorDAL dal = new authorDAL(Transaction, Connection))
			{
				return dal.GetAll();
			}
		}

		public authorModel GetByAuthorID(Int32 AuthorID)
		{
			using (authorDAL dal = new authorDAL(Transaction, Connection))
			{
				return dal.GetByAuthorID(AuthorID);
			}
		}

		public bool GetByAuthorID(Int32 AuthorID, authorModel result)
		{
			using (authorDAL dal = new authorDAL(Transaction, Connection))
			{
				return dal.GetByAuthorID(AuthorID, result);
			}
		}

		public void Update(authorModel model)
		{
			using (authorDAL dal = new authorDAL(Transaction, Connection))
			{
				dal.Update(model);
			}
		}

		public Int32 Insert(authorModel model)
		{
			using (authorDAL dal = new authorDAL(Transaction, Connection))
			{
				
				return dal.Insert(model);
			}
		}

		public void Delete(Int32 AuthorID)
		{
			using (authorDAL dal = new authorDAL(Transaction,Connection))
			{
				dal.Delete(AuthorID);
			}
		}




		public authorModel GetByName(String Name)
		{
			using (authorDAL dal = new authorDAL(Transaction, Connection))
			{
				return dal.GetByName(Name);
			}
		}

		public void DeleteByName(String Name)
		{
			using (authorDAL dal = new authorDAL(Transaction,Connection))
			{
				dal.DeleteByName(Name);
			}
		}
	}

	/// <summary>
	/// Business logic for images
	/// </summary>
	public partial class imagesBLL : Ows_indexBLLBase
	{
		public List<imagesModel> GetAll()
		{
			using (imagesDAL dal = new imagesDAL(Transaction, Connection))
			{
				return dal.GetAll();
			}
		}

		public imagesModel GetByid(UInt32 id)
		{
			using (imagesDAL dal = new imagesDAL(Transaction, Connection))
			{
				return dal.GetByid(id);
			}
		}

		public bool GetByid(UInt32 id, imagesModel result)
		{
			using (imagesDAL dal = new imagesDAL(Transaction, Connection))
			{
				return dal.GetByid(id, result);
			}
		}

		public void Update(imagesModel model)
		{
			using (imagesDAL dal = new imagesDAL(Transaction, Connection))
			{
				dal.Update(model);
			}
		}

		public void Insert(imagesModel model)
		{
			using (imagesDAL dal = new imagesDAL(Transaction, Connection))
			{
				
				dal.Insert(model);
			}
		}

		public void Delete(UInt32 id)
		{
			using (imagesDAL dal = new imagesDAL(Transaction,Connection))
			{
				dal.Delete(id);
			}
		}



	}

	/// <summary>
	/// Business logic for mp3
	/// </summary>
	public partial class mp3BLL : Ows_indexBLLBase
	{
		public List<mp3Model> GetAll()
		{
			using (mp3DAL dal = new mp3DAL(Transaction, Connection))
			{
				return dal.GetAll();
			}
		}

		public mp3Model GetByid(UInt32 id)
		{
			using (mp3DAL dal = new mp3DAL(Transaction, Connection))
			{
				return dal.GetByid(id);
			}
		}

		public bool GetByid(UInt32 id, mp3Model result)
		{
			using (mp3DAL dal = new mp3DAL(Transaction, Connection))
			{
				return dal.GetByid(id, result);
			}
		}

		public void Update(mp3Model model)
		{
			using (mp3DAL dal = new mp3DAL(Transaction, Connection))
			{
				dal.Update(model);
			}
		}

		public void Insert(mp3Model model)
		{
			using (mp3DAL dal = new mp3DAL(Transaction, Connection))
			{
				
				dal.Insert(model);
			}
		}

		public void Delete(UInt32 id)
		{
			using (mp3DAL dal = new mp3DAL(Transaction,Connection))
			{
				dal.Delete(id);
			}
		}



	}

	/// <summary>
	/// Business logic for pages
	/// </summary>
	public partial class pagesBLL : Ows_indexBLLBase
	{
		public List<pagesModel> GetAll()
		{
			using (pagesDAL dal = new pagesDAL(Transaction, Connection))
			{
				return dal.GetAll();
			}
		}

		public pagesModel GetByid(Int32 id)
		{
			using (pagesDAL dal = new pagesDAL(Transaction, Connection))
			{
				return dal.GetByid(id);
			}
		}

		public bool GetByid(Int32 id, pagesModel result)
		{
			using (pagesDAL dal = new pagesDAL(Transaction, Connection))
			{
				return dal.GetByid(id, result);
			}
		}

		public void Update(pagesModel model)
		{
			using (pagesDAL dal = new pagesDAL(Transaction, Connection))
			{
				dal.Update(model);
			}
		}

		public Int32 Insert(pagesModel model)
		{
			using (pagesDAL dal = new pagesDAL(Transaction, Connection))
			{
				
				return dal.Insert(model);
			}
		}

		public void Delete(Int32 id)
		{
			using (pagesDAL dal = new pagesDAL(Transaction,Connection))
			{
				dal.Delete(id);
			}
		}



	}

	/// <summary>
	/// Business logic for pdf
	/// </summary>
	public partial class pdfBLL : Ows_indexBLLBase
	{
		public List<pdfModel> GetAll()
		{
			using (pdfDAL dal = new pdfDAL(Transaction, Connection))
			{
				return dal.GetAll();
			}
		}

		public pdfModel GetByid(UInt32 id)
		{
			using (pdfDAL dal = new pdfDAL(Transaction, Connection))
			{
				return dal.GetByid(id);
			}
		}

		public bool GetByid(UInt32 id, pdfModel result)
		{
			using (pdfDAL dal = new pdfDAL(Transaction, Connection))
			{
				return dal.GetByid(id, result);
			}
		}

		public void Update(pdfModel model)
		{
			using (pdfDAL dal = new pdfDAL(Transaction, Connection))
			{
				dal.Update(model);
			}
		}

		public void Insert(pdfModel model)
		{
			using (pdfDAL dal = new pdfDAL(Transaction, Connection))
			{
				
				dal.Insert(model);
			}
		}

		public void Delete(UInt32 id)
		{
			using (pdfDAL dal = new pdfDAL(Transaction,Connection))
			{
				dal.Delete(id);
			}
		}



	}

}

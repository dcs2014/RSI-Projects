using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;
using SalarDb.CodeGen.Common;

namespace SalarDb.CodeGen.Base
{
	public class Ows_indexDALBase : IDisposable
	{
		#region variables
		private Ows_indexDbTransaction _Transaction = null;
		private IDbConnection _Connection = null;
		#endregion

		#region properties
		public Ows_indexDbTransaction Transaction
		{
			get { return _Transaction; }
			set { _Transaction = value; }
		}
		public IDbConnection Connection
		{
			get { return _Connection; }
			set { _Connection = value; }
		}
		#endregion

		#region public methods
		public void Dispose()
		{

		}
		#endregion

		#region protected methods
		protected MySqlCommand GetNewCommand()
		{
			IDbConnection conn = _Connection;
			if (conn == null)
			{
				if (_Transaction != null && _Transaction.Connection != null)
				{
					// Getting command from transaction
					return _Transaction.GetNewCommand();
				}
				else
					conn = Ows_indexDbProvider.GetNewConnection();
			}
			return (MySqlCommand)conn.CreateCommand();
		}
		#endregion
	}
}

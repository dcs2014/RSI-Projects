using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;

namespace SalarDb.CodeGen.Base
{
	public partial class Ows_indexModelBase : IDisposable
	{
		#region variables
		private Hashtable _Items;
		private bool _DataLoaded = false;
		#endregion

		#region properties
		public object this[string name]
		{
			get
			{
				if (_Items == null)
					return null;

				return _Items[name];
			}
			set
			{
				if (_Items == null)
					_Items = new Hashtable();
				_Items[name] = value;
			}
		}
		public bool DataLoaded
		{
			get { return _DataLoaded; }
		}
		#endregion

		#region public methods
		public virtual void ReadData(IDataReader dataReader)
		{
		}
		public void Dispose()
		{
		}
		#endregion

		#region protected methods
		protected void SetDataLoaded(bool loaded)
		{
			_DataLoaded = loaded;
		}
		#endregion
	}
}

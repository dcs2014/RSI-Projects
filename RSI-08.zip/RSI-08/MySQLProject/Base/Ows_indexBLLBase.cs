using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using SalarDb.CodeGen.Common;
using SalarDb.CodeGen.BLL;

namespace SalarDb.CodeGen.Base
{
	public partial class Ows_indexBLLBase : IDisposable
	{
		#region variables
		private Ows_indexDbTransaction _Transaction = null;
		private IDbConnection _Connection = null;
		#endregion

		#region properties
		public Ows_indexDbTransaction Transaction
		{
			get { return _Transaction; }
			set { _Transaction = value; }
		}
		public IDbConnection Connection
		{
			get { return _Connection; }
			set { _Connection = value; }
		}
		#endregion

		#region public methods
		public void Dispose()
		{
		}
		#endregion
	}
}

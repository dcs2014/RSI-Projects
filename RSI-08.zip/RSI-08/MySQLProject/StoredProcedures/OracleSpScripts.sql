
		
IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].author_GetALL') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].author_GetALL
GO
-- ==========================================================================================
-- Entity Name:	author_GetALL
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting all rows from author table
-- ==========================================================================================
CREATE PROCEDURE [dbo].author_GetALL
AS
	SET NOCOUNT ON

	SELECT *  FROM author
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].author_Insert') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].author_Insert
GO
-- ==========================================================================================
-- Entity Name:	author_Insert
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for inserting values to author table
-- ==========================================================================================
CREATE PROCEDURE [dbo].author_Insert
(
	
	@Name varchar(40) = NULL,
	@Birthday datetime,
	@LastActivity datetime = NULL,
	@Earnings decimal(38,6) = NULL,
	@Active tinyint,
	@JobCity varchar(80) = NULL,
	@Comment varchar(80) = NULL,
	@Rate int
)
AS
	SET NOCOUNT ON

	INSERT INTO author
			([Name] ,[Birthday] ,[LastActivity] ,[Earnings] ,[Active] ,[JobCity] ,[Comment] ,[Rate] )
	VALUES	(@Name ,@Birthday ,@LastActivity ,@Earnings ,@Active ,@JobCity ,@Comment ,@Rate )
    

	SELECT  Scope_Identity() AS [AuthorID];
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].author_DeleteByAuthorID') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].author_DeleteByAuthorID
GO
-- ==========================================================================================
-- Entity Name:	author_DeleteByAuthorID
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for deleting a specific row from author table
-- ==========================================================================================
CREATE PROCEDURE [dbo].author_DeleteByAuthorID
	(
	@AuthorID int
	)
AS
	SET NOCOUNT ON

	DELETE FROM author WHERE [AuthorID]=@AuthorID
GO




IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].author_GetByAuthorID') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].author_GetByAuthorID
GO

-- ==========================================================================================
-- Entity Name:	author_GetByAuthorID
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting a row by specified primary key from author table
-- ==========================================================================================
CREATE PROCEDURE [dbo].author_GetByAuthorID
	(
	@AuthorID int
	)
AS
	SET NOCOUNT ON

	SELECT *  FROM author WHERE [AuthorID]=@AuthorID
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].author_Update') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].author_Update
GO

-- ==========================================================================================
-- Entity Name:	author_Update
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for updating 	author table
-- ==========================================================================================
CREATE PROCEDURE [dbo].author_Update
(
	
	@AuthorID int,
	@Name varchar(40) = NULL,
	@Birthday datetime,
	@LastActivity datetime = NULL,
	@Earnings decimal(38,6) = NULL,
	@Active tinyint,
	@JobCity varchar(80) = NULL,
	@Comment varchar(80) = NULL,
	@Rate int
)
AS
	SET NOCOUNT ON

	UPDATE author SET 

		[Name] = @Name ,
		[Birthday] = @Birthday ,
		[LastActivity] = @LastActivity ,
		[Earnings] = @Earnings ,
		[Active] = @Active ,
		[JobCity] = @JobCity ,
		[Comment] = @Comment ,
		[Rate] = @Rate 
	WHERE [AuthorID]=@AuthorID
GO





IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].author_GetByName') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].author_GetByName
GO

-- ==========================================================================================
-- Entity Name:	author_GetByName
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting a row by specified primary key from author table
-- ==========================================================================================
CREATE PROCEDURE [dbo].author_GetByName
	(
	@Name varchar(40)
	)
AS
	SET NOCOUNT ON

	SELECT *  FROM author WHERE [Name]=@Name
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].author_DeleteByName') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].author_DeleteByName
GO
-- ==========================================================================================
-- Entity Name:	author_DeleteByName
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for deleting a specific row from author table
-- ==========================================================================================
CREATE PROCEDURE [dbo].author_DeleteByName
	(
	@Name varchar(40)
	)
AS
	SET NOCOUNT ON

	DELETE FROM author WHERE [Name]=@Name
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].images_GetALL') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].images_GetALL
GO
-- ==========================================================================================
-- Entity Name:	images_GetALL
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting all rows from images table
-- ==========================================================================================
CREATE PROCEDURE [dbo].images_GetALL
AS
	SET NOCOUNT ON

	SELECT *  FROM images
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].images_Insert') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].images_Insert
GO
-- ==========================================================================================
-- Entity Name:	images_Insert
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for inserting values to images table
-- ==========================================================================================
CREATE PROCEDURE [dbo].images_Insert
(
	
	@id int,
	@src_host_id int,
	@src_page varchar(255),
	@image_host_id int,
	@image varchar(255),
	@alt_text varchar(255) = NULL,
	@title_text varchar(255) = NULL
)
AS
	SET NOCOUNT ON

	INSERT INTO images
			([id] ,[src_host_id] ,[src_page] ,[image_host_id] ,[image] ,[alt_text] ,[title_text] )
	VALUES	(@id ,@src_host_id ,@src_page ,@image_host_id ,@image ,@alt_text ,@title_text )
    

GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].images_DeleteByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].images_DeleteByid
GO
-- ==========================================================================================
-- Entity Name:	images_DeleteByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for deleting a specific row from images table
-- ==========================================================================================
CREATE PROCEDURE [dbo].images_DeleteByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	DELETE FROM images WHERE [id]=@id
GO




IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].images_GetByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].images_GetByid
GO

-- ==========================================================================================
-- Entity Name:	images_GetByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting a row by specified primary key from images table
-- ==========================================================================================
CREATE PROCEDURE [dbo].images_GetByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	SELECT *  FROM images WHERE [id]=@id
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].images_Update') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].images_Update
GO

-- ==========================================================================================
-- Entity Name:	images_Update
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for updating 	images table
-- ==========================================================================================
CREATE PROCEDURE [dbo].images_Update
(
	
	@id int,
	@src_host_id int,
	@src_page varchar(255),
	@image_host_id int,
	@image varchar(255),
	@alt_text varchar(255) = NULL,
	@title_text varchar(255) = NULL
)
AS
	SET NOCOUNT ON

	UPDATE images SET 

		[id] = @id ,
		[src_host_id] = @src_host_id ,
		[src_page] = @src_page ,
		[image_host_id] = @image_host_id ,
		[image] = @image ,
		[alt_text] = @alt_text ,
		[title_text] = @title_text 
	WHERE [id]=@id
GO





IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].mp3_GetALL') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].mp3_GetALL
GO
-- ==========================================================================================
-- Entity Name:	mp3_GetALL
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting all rows from mp3 table
-- ==========================================================================================
CREATE PROCEDURE [dbo].mp3_GetALL
AS
	SET NOCOUNT ON

	SELECT *  FROM mp3
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].mp3_Insert') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].mp3_Insert
GO
-- ==========================================================================================
-- Entity Name:	mp3_Insert
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for inserting values to mp3 table
-- ==========================================================================================
CREATE PROCEDURE [dbo].mp3_Insert
(
	
	@id int,
	@host_id int,
	@filename varchar(255),
	@mp3_size int,
	@mp3_artist varchar(250),
	@mp3_title varchar(250),
	@mp3_album varchar(250),
	@mp3_genre varchar(250),
	@mp3_duration int
)
AS
	SET NOCOUNT ON

	INSERT INTO mp3
			([id] ,[host_id] ,[filename] ,[mp3_size] ,[mp3_artist] ,[mp3_title] ,[mp3_album] ,[mp3_genre] ,[mp3_duration] )
	VALUES	(@id ,@host_id ,@filename ,@mp3_size ,@mp3_artist ,@mp3_title ,@mp3_album ,@mp3_genre ,@mp3_duration )
    

GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].mp3_DeleteByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].mp3_DeleteByid
GO
-- ==========================================================================================
-- Entity Name:	mp3_DeleteByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for deleting a specific row from mp3 table
-- ==========================================================================================
CREATE PROCEDURE [dbo].mp3_DeleteByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	DELETE FROM mp3 WHERE [id]=@id
GO




IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].mp3_GetByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].mp3_GetByid
GO

-- ==========================================================================================
-- Entity Name:	mp3_GetByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting a row by specified primary key from mp3 table
-- ==========================================================================================
CREATE PROCEDURE [dbo].mp3_GetByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	SELECT *  FROM mp3 WHERE [id]=@id
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].mp3_Update') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].mp3_Update
GO

-- ==========================================================================================
-- Entity Name:	mp3_Update
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for updating 	mp3 table
-- ==========================================================================================
CREATE PROCEDURE [dbo].mp3_Update
(
	
	@id int,
	@host_id int,
	@filename varchar(255),
	@mp3_size int,
	@mp3_artist varchar(250),
	@mp3_title varchar(250),
	@mp3_album varchar(250),
	@mp3_genre varchar(250),
	@mp3_duration int
)
AS
	SET NOCOUNT ON

	UPDATE mp3 SET 

		[id] = @id ,
		[host_id] = @host_id ,
		[filename] = @filename ,
		[mp3_size] = @mp3_size ,
		[mp3_artist] = @mp3_artist ,
		[mp3_title] = @mp3_title ,
		[mp3_album] = @mp3_album ,
		[mp3_genre] = @mp3_genre ,
		[mp3_duration] = @mp3_duration 
	WHERE [id]=@id
GO





IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pages_GetALL') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pages_GetALL
GO
-- ==========================================================================================
-- Entity Name:	pages_GetALL
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting all rows from pages table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pages_GetALL
AS
	SET NOCOUNT ON

	SELECT *  FROM pages
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pages_Insert') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pages_Insert
GO
-- ==========================================================================================
-- Entity Name:	pages_Insert
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for inserting values to pages table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pages_Insert
(
	
	@host_id int,
	@hostname varchar(100),
	@page varchar(255),
	@title varchar(255),
	@anchor_text varchar(255),
	@text longtext,
	@cache longblob = NULL,
	@html_md5 varchar(32),
	@level int,
	@rank int,
	@date varchar(10),
	@time varchar(10)
)
AS
	SET NOCOUNT ON

	INSERT INTO pages
			([host_id] ,[hostname] ,[page] ,[title] ,[anchor_text] ,[text] ,[cache] ,[html_md5] ,[level] ,[rank] ,[date] ,[time] )
	VALUES	(@host_id ,@hostname ,@page ,@title ,@anchor_text ,@text ,@cache ,@html_md5 ,@level ,@rank ,@date ,@time )
    

	SELECT  Scope_Identity() AS [id];
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pages_DeleteByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pages_DeleteByid
GO
-- ==========================================================================================
-- Entity Name:	pages_DeleteByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for deleting a specific row from pages table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pages_DeleteByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	DELETE FROM pages WHERE [id]=@id
GO




IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pages_GetByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pages_GetByid
GO

-- ==========================================================================================
-- Entity Name:	pages_GetByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting a row by specified primary key from pages table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pages_GetByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	SELECT *  FROM pages WHERE [id]=@id
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pages_Update') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pages_Update
GO

-- ==========================================================================================
-- Entity Name:	pages_Update
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for updating 	pages table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pages_Update
(
	
	@id int,
	@host_id int,
	@hostname varchar(100),
	@page varchar(255),
	@title varchar(255),
	@anchor_text varchar(255),
	@text longtext,
	@cache longblob = NULL,
	@html_md5 varchar(32),
	@level int,
	@rank int,
	@date varchar(10),
	@time varchar(10)
)
AS
	SET NOCOUNT ON

	UPDATE pages SET 

		[host_id] = @host_id ,
		[hostname] = @hostname ,
		[page] = @page ,
		[title] = @title ,
		[anchor_text] = @anchor_text ,
		[text] = @text ,
		[cache] = @cache ,
		[html_md5] = @html_md5 ,
		[level] = @level ,
		[rank] = @rank ,
		[date] = @date ,
		[time] = @time 
	WHERE [id]=@id
GO





IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pdf_GetALL') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pdf_GetALL
GO
-- ==========================================================================================
-- Entity Name:	pdf_GetALL
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting all rows from pdf table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pdf_GetALL
AS
	SET NOCOUNT ON

	SELECT *  FROM pdf
GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pdf_Insert') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pdf_Insert
GO
-- ==========================================================================================
-- Entity Name:	pdf_Insert
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for inserting values to pdf table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pdf_Insert
(
	
	@id int,
	@host_id int,
	@filename varchar(255),
	@pdf_size int,
	@pdf_text text
)
AS
	SET NOCOUNT ON

	INSERT INTO pdf
			([id] ,[host_id] ,[filename] ,[pdf_size] ,[pdf_text] )
	VALUES	(@id ,@host_id ,@filename ,@pdf_size ,@pdf_text )
    

GO

IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pdf_DeleteByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pdf_DeleteByid
GO
-- ==========================================================================================
-- Entity Name:	pdf_DeleteByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for deleting a specific row from pdf table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pdf_DeleteByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	DELETE FROM pdf WHERE [id]=@id
GO




IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pdf_GetByid') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pdf_GetByid
GO

-- ==========================================================================================
-- Entity Name:	pdf_GetByid
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for selecting a row by specified primary key from pdf table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pdf_GetByid
	(
	@id int
	)
AS
	SET NOCOUNT ON

	SELECT *  FROM pdf WHERE [id]=@id
GO


IF EXISTS (select * from dbo.sysobjects where id = object_id(N'[dbo].pdf_Update') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].pdf_Update
GO

-- ==========================================================================================
-- Entity Name:	pdf_Update
-- Generator:	Salar dotNET DbCodeGenerator
-- Create date:	11/23/2014 7:31:48 PM
-- Description:	This stored procedure is intended for updating 	pdf table
-- ==========================================================================================
CREATE PROCEDURE [dbo].pdf_Update
(
	
	@id int,
	@host_id int,
	@filename varchar(255),
	@pdf_size int,
	@pdf_text text
)
AS
	SET NOCOUNT ON

	UPDATE pdf SET 

		[id] = @id ,
		[host_id] = @host_id ,
		[filename] = @filename ,
		[pdf_size] = @pdf_size ,
		[pdf_text] = @pdf_text 
	WHERE [id]=@id
GO





	
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using SalarDb.CodeGen.Base;
using SalarDb.CodeGen.BLL;

namespace SalarDb.CodeGen.Model
{

	/// <summary>
	/// Business Model for author
	/// </summary>
	public partial class authorModel : Ows_indexModelBase
	{
		/// <summary>
		/// Caches fields ordinal order when reading bunch of data from author
		/// </summary>
		public class FieldsOrdinal
		{
			#region fields ordinal cache
			
			public Int32 AuthorID;
			public Int32 Name;
			public Int32 Birthday;
			public Int32 LastActivity;
			public Int32 Earnings;
			public Int32 Active;
			public Int32 JobCity;
			public Int32 Comment;
			public Int32 Rate;
			#endregion

			#region public methods
			public FieldsOrdinal(IDataReader dataReader)
			{
				
				AuthorID = dataReader.GetOrdinal("AuthorID");
				Name = dataReader.GetOrdinal("Name");
				Birthday = dataReader.GetOrdinal("Birthday");
				LastActivity = dataReader.GetOrdinal("LastActivity");
				Earnings = dataReader.GetOrdinal("Earnings");
				Active = dataReader.GetOrdinal("Active");
				JobCity = dataReader.GetOrdinal("JobCity");
				Comment = dataReader.GetOrdinal("Comment");
				Rate = dataReader.GetOrdinal("Rate");
			}
			#endregion
		}

		#region fields variables
		
		private Int32 _AuthorID;
		private String _Name;
		private DateTime _Birthday;
		private DateTime? _LastActivity;
		private Decimal? _Earnings;
		private Boolean _Active;
		private String _JobCity;
		private String _Comment;
		private Int32 _Rate;
		#endregion

		#region fields property
		
		/// <summary>
		/// 
		/// </summary>
		public Int32 AuthorID
		{
			get { return _AuthorID; }
			set { _AuthorID = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String Name
		{
			get { return _Name; }
			set { _Name = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime Birthday
		{
			get { return _Birthday; }
			set { _Birthday = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? LastActivity
		{
			get { return _LastActivity; }
			set { _LastActivity = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Decimal? Earnings
		{
			get { return _Earnings; }
			set { _Earnings = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Boolean Active
		{
			get { return _Active; }
			set { _Active = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String JobCity
		{
			get { return _JobCity; }
			set { _JobCity = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String Comment
		{
			get { return _Comment; }
			set { _Comment = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Int32 Rate
		{
			get { return _Rate; }
			set { _Rate = value; }
		}
		#endregion

		#region public methods
		public authorModel()
		{
		}


		public authorModel(Int32 AuthorID)
		{
			using (authorBLL bll = new authorBLL())
			{
				if (!bll.GetByAuthorID(AuthorID, this))
				{
					throw new ArgumentException();
				}
			}
		}
		
		public Int32 Insert()
		{
			using (authorBLL bll = new authorBLL())
			{
				
				return bll.Insert(this);
			}
		}

		public void Update()
		{
			using (authorBLL bll = new authorBLL())
			{
				bll.Update(this);
			}
		}

		public void Delete()
		{
			using (authorBLL bll = new authorBLL())
			{
				bll.Delete(this.AuthorID);
			}
		}


		/// <summary>
		/// Reads data by specified fields ordinal order cache
		/// </summary>
		public void ReadData(IDataReader dataReader, FieldsOrdinal fields)
		{
			
			_AuthorID = Convert.ToInt32(dataReader[fields.AuthorID]);
			if (dataReader.IsDBNull(fields.Name) == false)
				_Name = Convert.ToString(dataReader[fields.Name]);
			else
				_Name = null;

			_Birthday = Convert.ToDateTime(dataReader[fields.Birthday]);
			if (dataReader.IsDBNull(fields.LastActivity) == false)
				_LastActivity = Convert.ToDateTime(dataReader[fields.LastActivity]);
			else
				_LastActivity = null;

			if (dataReader.IsDBNull(fields.Earnings) == false)
				_Earnings = Convert.ToDecimal(dataReader[fields.Earnings]);
			else
				_Earnings = null;

			_Active = Convert.ToBoolean(dataReader[fields.Active]);
			if (dataReader.IsDBNull(fields.JobCity) == false)
				_JobCity = Convert.ToString(dataReader[fields.JobCity]);
			else
				_JobCity = null;

			if (dataReader.IsDBNull(fields.Comment) == false)
				_Comment = Convert.ToString(dataReader[fields.Comment]);
			else
				_Comment = null;

			_Rate = Convert.ToInt32(dataReader[fields.Rate]);

			// Model is ready
			SetDataLoaded(true);
		}

		/// <summary>
		/// Reads data from data reader
		/// </summary>
		public override void ReadData(IDataReader dataReader)
		{
			
			_AuthorID = Convert.ToInt32(dataReader["AuthorID"]);
			if (dataReader.IsDBNull(dataReader.GetOrdinal("Name")) == false)
				_Name = Convert.ToString(dataReader["Name"]);
			else
				_Name = null;

			_Birthday = Convert.ToDateTime(dataReader["Birthday"]);
			if (dataReader.IsDBNull(dataReader.GetOrdinal("LastActivity")) == false)
				_LastActivity = Convert.ToDateTime(dataReader["LastActivity"]);
			else
				_LastActivity = null;

			if (dataReader.IsDBNull(dataReader.GetOrdinal("Earnings")) == false)
				_Earnings = Convert.ToDecimal(dataReader["Earnings"]);
			else
				_Earnings = null;

			_Active = Convert.ToBoolean(dataReader["Active"]);
			if (dataReader.IsDBNull(dataReader.GetOrdinal("JobCity")) == false)
				_JobCity = Convert.ToString(dataReader["JobCity"]);
			else
				_JobCity = null;

			if (dataReader.IsDBNull(dataReader.GetOrdinal("Comment")) == false)
				_Comment = Convert.ToString(dataReader["Comment"]);
			else
				_Comment = null;

			_Rate = Convert.ToInt32(dataReader["Rate"]);

			// Model is ready
			SetDataLoaded(true);
		}
		#endregion
	}

	/// <summary>
	/// Business Model for images
	/// </summary>
	public partial class imagesModel : Ows_indexModelBase
	{
		/// <summary>
		/// Caches fields ordinal order when reading bunch of data from images
		/// </summary>
		public class FieldsOrdinal
		{
			#region fields ordinal cache
			
			public Int32 id;
			public Int32 src_host_id;
			public Int32 src_page;
			public Int32 image_host_id;
			public Int32 image;
			public Int32 alt_text;
			public Int32 title_text;
			#endregion

			#region public methods
			public FieldsOrdinal(IDataReader dataReader)
			{
				
				id = dataReader.GetOrdinal("id");
				src_host_id = dataReader.GetOrdinal("src_host_id");
				src_page = dataReader.GetOrdinal("src_page");
				image_host_id = dataReader.GetOrdinal("image_host_id");
				image = dataReader.GetOrdinal("image");
				alt_text = dataReader.GetOrdinal("alt_text");
				title_text = dataReader.GetOrdinal("title_text");
			}
			#endregion
		}

		#region fields variables
		
		private UInt32 _id;
		private UInt32 _src_host_id;
		private String _src_page;
		private UInt32 _image_host_id;
		private String _image;
		private String _alt_text;
		private String _title_text;
		#endregion

		#region fields property
		
		/// <summary>
		/// 
		/// </summary>
		public UInt32 id
		{
			get { return _id; }
			set { _id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public UInt32 src_host_id
		{
			get { return _src_host_id; }
			set { _src_host_id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String src_page
		{
			get { return _src_page; }
			set { _src_page = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public UInt32 image_host_id
		{
			get { return _image_host_id; }
			set { _image_host_id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String image
		{
			get { return _image; }
			set { _image = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String alt_text
		{
			get { return _alt_text; }
			set { _alt_text = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String title_text
		{
			get { return _title_text; }
			set { _title_text = value; }
		}
		#endregion

		#region public methods
		public imagesModel()
		{
		}


		
		public void Insert()
		{
			using (imagesBLL bll = new imagesBLL())
			{
				
				bll.Insert(this);
			}
		}

		public void Update()
		{
			using (imagesBLL bll = new imagesBLL())
			{
				bll.Update(this);
			}
		}

		public void Delete()
		{
			using (imagesBLL bll = new imagesBLL())
			{
				bll.Delete(this.id);
			}
		}


		/// <summary>
		/// Reads data by specified fields ordinal order cache
		/// </summary>
		public void ReadData(IDataReader dataReader, FieldsOrdinal fields)
		{
			
			_id = Convert.ToUInt32(dataReader[fields.id]);
			_src_host_id = Convert.ToUInt32(dataReader[fields.src_host_id]);
			_src_page = Convert.ToString(dataReader[fields.src_page]);
			_image_host_id = Convert.ToUInt32(dataReader[fields.image_host_id]);
			_image = Convert.ToString(dataReader[fields.image]);
			if (dataReader.IsDBNull(fields.alt_text) == false)
				_alt_text = Convert.ToString(dataReader[fields.alt_text]);
			else
				_alt_text = null;

			if (dataReader.IsDBNull(fields.title_text) == false)
				_title_text = Convert.ToString(dataReader[fields.title_text]);
			else
				_title_text = null;


			// Model is ready
			SetDataLoaded(true);
		}

		/// <summary>
		/// Reads data from data reader
		/// </summary>
		public override void ReadData(IDataReader dataReader)
		{
			
			_id = Convert.ToUInt32(dataReader["id"]);
			_src_host_id = Convert.ToUInt32(dataReader["src_host_id"]);
			_src_page = Convert.ToString(dataReader["src_page"]);
			_image_host_id = Convert.ToUInt32(dataReader["image_host_id"]);
			_image = Convert.ToString(dataReader["image"]);
			if (dataReader.IsDBNull(dataReader.GetOrdinal("alt_text")) == false)
				_alt_text = Convert.ToString(dataReader["alt_text"]);
			else
				_alt_text = null;

			if (dataReader.IsDBNull(dataReader.GetOrdinal("title_text")) == false)
				_title_text = Convert.ToString(dataReader["title_text"]);
			else
				_title_text = null;


			// Model is ready
			SetDataLoaded(true);
		}
		#endregion
	}

	/// <summary>
	/// Business Model for mp3
	/// </summary>
	public partial class mp3Model : Ows_indexModelBase
	{
		/// <summary>
		/// Caches fields ordinal order when reading bunch of data from mp3
		/// </summary>
		public class FieldsOrdinal
		{
			#region fields ordinal cache
			
			public Int32 id;
			public Int32 host_id;
			public Int32 filename;
			public Int32 mp3_size;
			public Int32 mp3_artist;
			public Int32 mp3_title;
			public Int32 mp3_album;
			public Int32 mp3_genre;
			public Int32 mp3_duration;
			#endregion

			#region public methods
			public FieldsOrdinal(IDataReader dataReader)
			{
				
				id = dataReader.GetOrdinal("id");
				host_id = dataReader.GetOrdinal("host_id");
				filename = dataReader.GetOrdinal("filename");
				mp3_size = dataReader.GetOrdinal("mp3_size");
				mp3_artist = dataReader.GetOrdinal("mp3_artist");
				mp3_title = dataReader.GetOrdinal("mp3_title");
				mp3_album = dataReader.GetOrdinal("mp3_album");
				mp3_genre = dataReader.GetOrdinal("mp3_genre");
				mp3_duration = dataReader.GetOrdinal("mp3_duration");
			}
			#endregion
		}

		#region fields variables
		
		private UInt32 _id;
		private Int32 _host_id;
		private String _filename;
		private Int32 _mp3_size;
		private String _mp3_artist;
		private String _mp3_title;
		private String _mp3_album;
		private String _mp3_genre;
		private Int32 _mp3_duration;
		#endregion

		#region fields property
		
		/// <summary>
		/// 
		/// </summary>
		public UInt32 id
		{
			get { return _id; }
			set { _id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Int32 host_id
		{
			get { return _host_id; }
			set { _host_id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String filename
		{
			get { return _filename; }
			set { _filename = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Int32 mp3_size
		{
			get { return _mp3_size; }
			set { _mp3_size = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String mp3_artist
		{
			get { return _mp3_artist; }
			set { _mp3_artist = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String mp3_title
		{
			get { return _mp3_title; }
			set { _mp3_title = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String mp3_album
		{
			get { return _mp3_album; }
			set { _mp3_album = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String mp3_genre
		{
			get { return _mp3_genre; }
			set { _mp3_genre = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Int32 mp3_duration
		{
			get { return _mp3_duration; }
			set { _mp3_duration = value; }
		}
		#endregion

		#region public methods
		public mp3Model()
		{
		}


		
		public void Insert()
		{
			using (mp3BLL bll = new mp3BLL())
			{
				
				bll.Insert(this);
			}
		}

		public void Update()
		{
			using (mp3BLL bll = new mp3BLL())
			{
				bll.Update(this);
			}
		}

		public void Delete()
		{
			using (mp3BLL bll = new mp3BLL())
			{
				bll.Delete(this.id);
			}
		}


		/// <summary>
		/// Reads data by specified fields ordinal order cache
		/// </summary>
		public void ReadData(IDataReader dataReader, FieldsOrdinal fields)
		{
			
			_id = Convert.ToUInt32(dataReader[fields.id]);
			_host_id = Convert.ToInt32(dataReader[fields.host_id]);
			_filename = Convert.ToString(dataReader[fields.filename]);
			_mp3_size = Convert.ToInt32(dataReader[fields.mp3_size]);
			_mp3_artist = Convert.ToString(dataReader[fields.mp3_artist]);
			_mp3_title = Convert.ToString(dataReader[fields.mp3_title]);
			_mp3_album = Convert.ToString(dataReader[fields.mp3_album]);
			_mp3_genre = Convert.ToString(dataReader[fields.mp3_genre]);
			_mp3_duration = Convert.ToInt32(dataReader[fields.mp3_duration]);

			// Model is ready
			SetDataLoaded(true);
		}

		/// <summary>
		/// Reads data from data reader
		/// </summary>
		public override void ReadData(IDataReader dataReader)
		{
			
			_id = Convert.ToUInt32(dataReader["id"]);
			_host_id = Convert.ToInt32(dataReader["host_id"]);
			_filename = Convert.ToString(dataReader["filename"]);
			_mp3_size = Convert.ToInt32(dataReader["mp3_size"]);
			_mp3_artist = Convert.ToString(dataReader["mp3_artist"]);
			_mp3_title = Convert.ToString(dataReader["mp3_title"]);
			_mp3_album = Convert.ToString(dataReader["mp3_album"]);
			_mp3_genre = Convert.ToString(dataReader["mp3_genre"]);
			_mp3_duration = Convert.ToInt32(dataReader["mp3_duration"]);

			// Model is ready
			SetDataLoaded(true);
		}
		#endregion
	}

	/// <summary>
	/// Business Model for pages
	/// </summary>
	public partial class pagesModel : Ows_indexModelBase
	{
		/// <summary>
		/// Caches fields ordinal order when reading bunch of data from pages
		/// </summary>
		public class FieldsOrdinal
		{
			#region fields ordinal cache
			
			public Int32 id;
			public Int32 host_id;
			public Int32 hostname;
			public Int32 page;
			public Int32 title;
			public Int32 anchor_text;
			public Int32 text;
			public Int32 cache;
			public Int32 html_md5;
			public Int32 level;
			public Int32 rank;
			public Int32 date;
			public Int32 time;
			#endregion

			#region public methods
			public FieldsOrdinal(IDataReader dataReader)
			{
				
				id = dataReader.GetOrdinal("id");
				host_id = dataReader.GetOrdinal("host_id");
				hostname = dataReader.GetOrdinal("hostname");
				page = dataReader.GetOrdinal("page");
				title = dataReader.GetOrdinal("title");
				anchor_text = dataReader.GetOrdinal("anchor_text");
				text = dataReader.GetOrdinal("text");
				cache = dataReader.GetOrdinal("cache");
				html_md5 = dataReader.GetOrdinal("html_md5");
				level = dataReader.GetOrdinal("level");
				rank = dataReader.GetOrdinal("rank");
				date = dataReader.GetOrdinal("date");
				time = dataReader.GetOrdinal("time");
			}
			#endregion
		}

		#region fields variables
		
		private Int32 _id;
		private UInt32 _host_id;
		private String _hostname;
		private String _page;
		private String _title;
		private String _anchor_text;
		private String _text;
		private Byte[] _cache;
		private String _html_md5;
		private UInt32 _level;
		private UInt32 _rank;
		private String _date;
		private String _time;
		#endregion

		#region fields property
		
		/// <summary>
		/// 
		/// </summary>
		public Int32 id
		{
			get { return _id; }
			set { _id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public UInt32 host_id
		{
			get { return _host_id; }
			set { _host_id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String hostname
		{
			get { return _hostname; }
			set { _hostname = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String page
		{
			get { return _page; }
			set { _page = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String title
		{
			get { return _title; }
			set { _title = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String anchor_text
		{
			get { return _anchor_text; }
			set { _anchor_text = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String text
		{
			get { return _text; }
			set { _text = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Byte[] cache
		{
			get { return _cache; }
			set { _cache = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String html_md5
		{
			get { return _html_md5; }
			set { _html_md5 = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public UInt32 level
		{
			get { return _level; }
			set { _level = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public UInt32 rank
		{
			get { return _rank; }
			set { _rank = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String date
		{
			get { return _date; }
			set { _date = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String time
		{
			get { return _time; }
			set { _time = value; }
		}
		#endregion

		#region public methods
		public pagesModel()
		{
		}


		public pagesModel(Int32 id)
		{
			using (pagesBLL bll = new pagesBLL())
			{
				if (!bll.GetByid(id, this))
				{
					throw new ArgumentException();
				}
			}
		}
		
		public Int32 Insert()
		{
			using (pagesBLL bll = new pagesBLL())
			{
				
				return bll.Insert(this);
			}
		}

		public void Update()
		{
			using (pagesBLL bll = new pagesBLL())
			{
				bll.Update(this);
			}
		}

		public void Delete()
		{
			using (pagesBLL bll = new pagesBLL())
			{
				bll.Delete(this.id);
			}
		}


		/// <summary>
		/// Reads data by specified fields ordinal order cache
		/// </summary>
		public void ReadData(IDataReader dataReader, FieldsOrdinal fields)
		{
			
			_id = Convert.ToInt32(dataReader[fields.id]);
			_host_id = Convert.ToUInt32(dataReader[fields.host_id]);
			_hostname = Convert.ToString(dataReader[fields.hostname]);
			_page = Convert.ToString(dataReader[fields.page]);
			_title = Convert.ToString(dataReader[fields.title]);
			_anchor_text = Convert.ToString(dataReader[fields.anchor_text]);
			_text = Convert.ToString(dataReader[fields.text]);
			if (dataReader.IsDBNull(fields.cache) == false)
				_cache = (Byte[])(dataReader[fields.cache]);
			else
				_cache = null;

			_html_md5 = Convert.ToString(dataReader[fields.html_md5]);
			_level = Convert.ToUInt32(dataReader[fields.level]);
			_rank = Convert.ToUInt32(dataReader[fields.rank]);
			_date = Convert.ToString(dataReader[fields.date]);
			_time = Convert.ToString(dataReader[fields.time]);

			// Model is ready
			SetDataLoaded(true);
		}

		/// <summary>
		/// Reads data from data reader
		/// </summary>
		public override void ReadData(IDataReader dataReader)
		{
			
			_id = Convert.ToInt32(dataReader["id"]);
			_host_id = Convert.ToUInt32(dataReader["host_id"]);
			_hostname = Convert.ToString(dataReader["hostname"]);
			_page = Convert.ToString(dataReader["page"]);
			_title = Convert.ToString(dataReader["title"]);
			_anchor_text = Convert.ToString(dataReader["anchor_text"]);
			_text = Convert.ToString(dataReader["text"]);
			if (dataReader.IsDBNull(dataReader.GetOrdinal("cache")) == false)
				_cache = (Byte[])(dataReader["cache"]);
			else
				_cache = null;

			_html_md5 = Convert.ToString(dataReader["html_md5"]);
			_level = Convert.ToUInt32(dataReader["level"]);
			_rank = Convert.ToUInt32(dataReader["rank"]);
			_date = Convert.ToString(dataReader["date"]);
			_time = Convert.ToString(dataReader["time"]);

			// Model is ready
			SetDataLoaded(true);
		}
		#endregion
	}

	/// <summary>
	/// Business Model for pdf
	/// </summary>
	public partial class pdfModel : Ows_indexModelBase
	{
		/// <summary>
		/// Caches fields ordinal order when reading bunch of data from pdf
		/// </summary>
		public class FieldsOrdinal
		{
			#region fields ordinal cache
			
			public Int32 id;
			public Int32 host_id;
			public Int32 filename;
			public Int32 pdf_size;
			public Int32 pdf_text;
			#endregion

			#region public methods
			public FieldsOrdinal(IDataReader dataReader)
			{
				
				id = dataReader.GetOrdinal("id");
				host_id = dataReader.GetOrdinal("host_id");
				filename = dataReader.GetOrdinal("filename");
				pdf_size = dataReader.GetOrdinal("pdf_size");
				pdf_text = dataReader.GetOrdinal("pdf_text");
			}
			#endregion
		}

		#region fields variables
		
		private UInt32 _id;
		private Int32 _host_id;
		private String _filename;
		private Int32 _pdf_size;
		private String _pdf_text;
		#endregion

		#region fields property
		
		/// <summary>
		/// 
		/// </summary>
		public UInt32 id
		{
			get { return _id; }
			set { _id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Int32 host_id
		{
			get { return _host_id; }
			set { _host_id = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String filename
		{
			get { return _filename; }
			set { _filename = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public Int32 pdf_size
		{
			get { return _pdf_size; }
			set { _pdf_size = value; }
		}
		/// <summary>
		/// 
		/// </summary>
		public String pdf_text
		{
			get { return _pdf_text; }
			set { _pdf_text = value; }
		}
		#endregion

		#region public methods
		public pdfModel()
		{
		}


		
		public void Insert()
		{
			using (pdfBLL bll = new pdfBLL())
			{
				
				bll.Insert(this);
			}
		}

		public void Update()
		{
			using (pdfBLL bll = new pdfBLL())
			{
				bll.Update(this);
			}
		}

		public void Delete()
		{
			using (pdfBLL bll = new pdfBLL())
			{
				bll.Delete(this.id);
			}
		}


		/// <summary>
		/// Reads data by specified fields ordinal order cache
		/// </summary>
		public void ReadData(IDataReader dataReader, FieldsOrdinal fields)
		{
			
			_id = Convert.ToUInt32(dataReader[fields.id]);
			_host_id = Convert.ToInt32(dataReader[fields.host_id]);
			_filename = Convert.ToString(dataReader[fields.filename]);
			_pdf_size = Convert.ToInt32(dataReader[fields.pdf_size]);
			_pdf_text = Convert.ToString(dataReader[fields.pdf_text]);

			// Model is ready
			SetDataLoaded(true);
		}

		/// <summary>
		/// Reads data from data reader
		/// </summary>
		public override void ReadData(IDataReader dataReader)
		{
			
			_id = Convert.ToUInt32(dataReader["id"]);
			_host_id = Convert.ToInt32(dataReader["host_id"]);
			_filename = Convert.ToString(dataReader["filename"]);
			_pdf_size = Convert.ToInt32(dataReader["pdf_size"]);
			_pdf_text = Convert.ToString(dataReader["pdf_text"]);

			// Model is ready
			SetDataLoaded(true);
		}
		#endregion
	}

}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data;

namespace MySQLProjects
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        SalarDb.CodeGen.Base.Ows_indexModelBase mb {get; set;}

         SalarDb.CodeGen.Base.Ows_indexDALBase db {get; set;}

         SalarDb.CodeGen.Base.Ows_indexBLLBase bb {get; set;}


         public static void AddOrUpdateAppSettings(string key, string value)
         {
             try
             {
                 var configFile = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                 var settings = configFile.AppSettings.Settings;
                 if (settings[key] == null)
                 {
                     settings.Add(key, value);
                 }
                 else
                 {
                     settings[key].Value = value;
                 }
                 configFile.Save(ConfigurationSaveMode.Modified);
                 ConfigurationManager.RefreshSection(configFile.AppSettings.SectionInformation.Name);
             }
             catch (ConfigurationErrorsException)
             {
                 Console.WriteLine("Error writing app settings");
             }
         }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {

        

            //AddOrUpdateAppSettings("Ows_indexConnectionString", "Server = 127.0.0.1; Database = ows_index; Uid = root; Pwd =");


            //ConfigurationManager.ConnectionStrings.Add("Ows_indexConnectionString", "Server = 127.0.0.1; Database = ows_index; Uid = root; Pwd =");

            SalarDb.CodeGen.BLL.pagesBLL pg = new SalarDb.CodeGen.BLL.pagesBLL();

            List<SalarDb.CodeGen.Model.pagesModel> p = pg.GetAll();

            listBox1.Items.Clear();

            treeView1.Nodes.Clear();

            foreach(object obs in p){

                SalarDb.CodeGen.Model.pagesModel m = obs as SalarDb.CodeGen.Model.pagesModel;
                

                listBox1.Items.Add(m.title);

                TreeNode node = new TreeNode();

                node.Text = m.title;

                node.Tag = m.text;

                treeView1.Nodes.Add(node);
            }

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            TreeNode node = e.Node;

            if (node == null)
                return;

            if (node.Tag == null)
                return;

            string s = node.Tag as string;

            richTextBox1.Text = s;
        }
    }
}

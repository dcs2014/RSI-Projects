package org.javaee7.interceptor.aroundconstruct;

/**
 * @author Radim Hanus
 */
public interface Param {
	String getValue();
}

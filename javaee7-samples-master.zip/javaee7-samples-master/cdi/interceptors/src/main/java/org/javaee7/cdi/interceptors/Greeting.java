package org.javaee7.cdi.interceptors;

/**
 * @author Arun Gupta
 * @author Radim Hanus
 */
public interface Greeting {
    public String getGreet();
    public void setGreet(String name);
}

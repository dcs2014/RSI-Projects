package org.javaee7.cdisamples.beanmanager;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

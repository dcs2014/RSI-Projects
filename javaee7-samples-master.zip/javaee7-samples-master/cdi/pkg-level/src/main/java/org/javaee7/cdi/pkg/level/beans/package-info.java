@Vetoed
package org.javaee7.cdi.pkg.level.beans;

import javax.enterprise.inject.Vetoed;


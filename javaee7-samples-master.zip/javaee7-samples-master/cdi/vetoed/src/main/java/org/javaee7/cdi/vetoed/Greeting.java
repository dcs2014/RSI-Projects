package org.javaee7.cdi.vetoed;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

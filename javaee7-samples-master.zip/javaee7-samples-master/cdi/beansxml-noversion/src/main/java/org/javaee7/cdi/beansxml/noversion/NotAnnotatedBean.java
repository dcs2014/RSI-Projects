package org.javaee7.cdi.beansxml.noversion;

/**
 * @author Alexis Hassler
 */
public class NotAnnotatedBean {
    public String sayHello(String name) {
        return "Hello " + name;
    }
}

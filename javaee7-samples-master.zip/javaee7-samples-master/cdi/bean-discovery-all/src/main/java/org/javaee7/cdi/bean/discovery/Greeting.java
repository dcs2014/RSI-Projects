package org.javaee7.cdi.bean.discovery;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

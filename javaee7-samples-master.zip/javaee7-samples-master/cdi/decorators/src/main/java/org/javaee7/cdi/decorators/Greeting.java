package org.javaee7.cdi.decorators;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

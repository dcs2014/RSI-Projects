package org.javaee7.cdi.alternatives;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

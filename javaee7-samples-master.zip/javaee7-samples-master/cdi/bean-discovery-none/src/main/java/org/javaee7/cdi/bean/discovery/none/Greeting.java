package org.javaee7.cdi.bean.discovery.none;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

package org.javaee7.cdi.bean.discovery.annotated;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

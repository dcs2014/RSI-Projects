package org.javaee7.cdi.built.in;

/**
 * @author Arun Gupta
 */
public interface Greeting {
    public String greet(String name);
}

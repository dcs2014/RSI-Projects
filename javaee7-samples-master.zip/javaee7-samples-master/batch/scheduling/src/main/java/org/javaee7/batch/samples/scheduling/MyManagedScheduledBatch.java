package org.javaee7.batch.samples.scheduling;

/**
 * @author Roberto Cortez
 */
public interface MyManagedScheduledBatch {
    void runJob();
}

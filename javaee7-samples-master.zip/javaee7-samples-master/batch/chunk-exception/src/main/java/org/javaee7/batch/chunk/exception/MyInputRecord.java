package org.javaee7.batch.chunk.exception;

import java.io.Serializable;

/**
 * @author Arun Gupta
 */
public class MyInputRecord implements Serializable {
    private int id;

    public MyInputRecord(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MyInputRecord that = (MyInputRecord) o;

        return id == that.id;
    }

    @Override
    public int hashCode() {
        return id;
    }

    @Override
    public String toString() {
        return "MyInputRecord: " + id;
    }
}

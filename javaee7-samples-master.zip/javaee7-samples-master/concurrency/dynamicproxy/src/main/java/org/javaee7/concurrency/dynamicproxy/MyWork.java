package org.javaee7.concurrency.dynamicproxy;

/**
 * @author Arun Gupta
 */
public interface MyWork {
    public void myWork();
}
